foreach ($array as $key => $value) {
echo "Key is $key."; echo "Value is $value.";
}
