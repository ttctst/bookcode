<?php
$query = new WP_Query(array('post_type' => 'post',
'comment_count' => 20););
?>
