<?php
$args = array(
'post_type' => 'post',
'comment_count' => 20,
);
$query = new WP_Query( $args );
?>
