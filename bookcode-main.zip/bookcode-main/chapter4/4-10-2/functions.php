<?php
$user_query = new WP_User_Query( array( 'role' => 'Subscriber' ) );
?>
