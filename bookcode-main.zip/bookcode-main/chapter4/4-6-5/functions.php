

<?php
add_theme_support( 'post-thumbnails' );
add_image_size( 'sidebar-thumb', 120, 9999, array( 'left', 'top' ));
?>
